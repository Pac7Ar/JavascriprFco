import db.conexion.ConexionDB;

public class App {
    public static void main(String[] args) {
        
    }
}