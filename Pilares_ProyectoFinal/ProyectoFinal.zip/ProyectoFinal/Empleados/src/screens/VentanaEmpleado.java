package screens;

public class VentanaEmpleado {
    
}
