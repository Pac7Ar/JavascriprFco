package helpers;

public class Password {
    
}
