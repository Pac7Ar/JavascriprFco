package db.repositorys;

public class LoginRepository {
    
    
}
